using System.Collections;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using VRStandardAssets.Common;
using VRStandardAssets.Utils;

namespace VRStandardAssets.Flyer
{
    // The script controls the UI for the flyer scene.
    public class UIController : MonoBehaviour
    {
        [SerializeField]
        private UIFader m_IntroUI;     // Reference to the script that controls the fading of the intro UI.
        [SerializeField]
        private UIFader m_OutroUI;     // Reference to the script that controls the fading of the outro UI.
        [SerializeField]
        private Text m_TotalScore;     // The text component used to display the score for this session.
        [SerializeField]
        private Text m_HighScore;      // The text component used to display the high score.


        [SerializeField]
        private UIFader m_GameOverUI;



        public IEnumerator ShowIntroUI()
        {
            // Interupt any fading the intro UI is already doing and fade in, return when finished.
            yield return StartCoroutine(m_IntroUI.InteruptAndFadeIn());
        }

        public IEnumerator HideIntroUI()
        {
            // Interupt any fading the outro UI is already doing and fade out, return when finished.
            yield return StartCoroutine(m_IntroUI.InteruptAndFadeOut());
        }

        public IEnumerator ShowOutroUI()
        {
            // Set the text to show the various scores.
            m_TotalScore.text = SessionData.Score.ToString();
            m_HighScore.text = SessionData.HighScore.ToString();

            // Wait for the outro to fade in.
            yield return StartCoroutine(m_OutroUI.InteruptAndFadeIn());
        }
        public IEnumerator HideOutroUI()
        {
            // Wait for the outro to fade out.
            yield return StartCoroutine(m_OutroUI.InteruptAndFadeOut());
        }

        public IEnumerator ShowGameOver()
        {
            Text text = m_GameOverUI.transform.FindChild("Content").GetComponent<Text>();

            string content = "";
            int count = GlobalData.m_recordMgr.m_dataList.Count;
            count = count > 10 ? 10 : count; //���а�ȡǰ10��
            for (int i = 0; i < count; i++)
            {
                RecordItem item = GlobalData.m_recordMgr.m_dataList[i];
                if (RecordMgr.Inst.currId == item.m_id) //���Լ�,������ʾ
                {
                    content += "<color=#00ff00ff>" + "\t" + (i + 1) + "\t\t\t\t\t" + item.m_score + "</color>" + "\n";
                }
                else
                {
                    content += "\t" +(i + 1) + "\t\t\t\t\t" + item.m_score + "\n";
                }
            }
            content += "\nPlayer Score:" + "\t"+GlobalData.m_score;
            text.text = content;
            text.text = text.text.Replace("\\n", "\n");


            // Wait for the outro to fade in.
            yield return StartCoroutine(m_GameOverUI.InteruptAndFadeIn());
        }
        public IEnumerator HideGameOver()
        {
            // Wait for the outro to fade out.
            yield return StartCoroutine(m_GameOverUI.InteruptAndFadeOut());
        }

    }
}