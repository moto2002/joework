﻿using UnityEngine;
using System.Collections;
using System;
using VRStandardAssets.Flyer;


public class Zhuzi : MonoBehaviour
{

    public event Action<Zhuzi> OnZhuziRemove;
    private Transform m_Cam;
    private GameObject m_Flyer;
    private const float k_RemovalDistance = 50f;
    private FlyerHealthController m_FlyerHealthController;
    private FlyerMovementController m_flyerMovementController;

    void Awake()
    {
        // Set references to the camera and flyer.
        m_Cam = Camera.main.transform;
        m_Flyer = GameObject.FindGameObjectWithTag("Player");

        m_FlyerHealthController = FindObjectOfType<FlyerHealthController>();
        m_Flyer = m_FlyerHealthController.gameObject;

        m_flyerMovementController =  m_Flyer.GetComponent<FlyerMovementController>();
    }

    void Start()
    {

    }

    void Update()
    {
        if (transform.position.z < m_Cam.position.z - k_RemovalDistance)
        {
            if (OnZhuziRemove != null)
                OnZhuziRemove(this);
        }

        
    }

    private void OnDestroy()
    {
        // Ensure the event is completely unsubscribed when the ring is destroyed.
        OnZhuziRemove = null;
    }

}
