using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VRStandardAssets.Common;
using VRStandardAssets.Utils;

namespace VRStandardAssets.Flyer
{
    // This script handles the spawning and some of the
    // interactions of Rings and Asteroids with the flyer.
    public class EnvironmentController : MonoBehaviour
    {
        [SerializeField]
        private float m_AsteroidSpawnFrequency = 3f;       // The time between asteroids spawning in seconds.
        [SerializeField]
        private float m_RingSpawnFrequency = 10f;          // The time between rings spawning in seconds.
        [SerializeField]
        private float m_WallSpawnFrequency = 1f;          // The time between rings spawning in seconds.

        [SerializeField]
        private float m_CoinSpawnFrequency = 1f;

        [SerializeField]
        private float m_CloudSpawnFrequency = 1f;
        [SerializeField]
        private float m_ZhuziSpawnFrequency = 1f;

        [SerializeField]
        private int m_InitialAsteroidCount = 10;           // The number of asteroids present at the start.
        [SerializeField]
        private float m_AsteroidSpawnZoneRadius = 120f;    // The radius of the sphere in which the asteroids spawn.
        [SerializeField]
        private float m_RingSpawnZoneRadius = 50f;         // The radius of the sphere in which the rings spawn.

        [SerializeField]
        private float m_WallSpawnZoneRadius = 50f;         // The radius of the sphere in which the walls spawn.


        [SerializeField]
        private float m_CoinSpawnZoneRadius = 50f;

        [SerializeField]
        private float m_CloudSpawnZoneRadius = 50f;

        [SerializeField]
        private float m_ZhuziSpawnZoneRadius = 0;

        [SerializeField]
        private float m_SpawnZoneDistance = 500f;          // The distance from the camera of the spawn spheres.
        [SerializeField]
        private ObjectPool m_AsteroidObjectPool;           // The object pool that stores the asteroids.
        [SerializeField]
        private ObjectPool m_AsteroidExplosionObjectPool;  // The object pool that stores the expolosions made when asteroids are hit.
        [SerializeField]
        private ObjectPool m_RingObjectPool;               // The object pool that stores the rings.
        [SerializeField]
        private ObjectPool m_WallObjectPool;               // The object pool that stores the rings.

        [SerializeField]
        private ObjectPool m_CoinObjectPool;

        [SerializeField]
        private ObjectPool m_CloudObjectPool;

        [SerializeField]
        private ObjectPool m_ZhuziObjectPool;

        [SerializeField]
        private Transform m_Cam;                           // Reference to the camera's position.




        private List<Ring> m_Rings;                                         // Collection of all the currently unpooled rings.
        private List<Asteroid> m_Asteroids;                                 // Collection of all the currently unpooled asteroids.
        private List<Wall> m_Walls;
        private List<Coin> m_Coins;
        private List<Cloud> m_Clouds;
        private List<Zhuzi> m_Zhuzis;
        private bool m_Spawning;                                            // Whether the environment should keep spawning rings and asteroids.


        public void StartEnvironment()
        {
            // Create new empty lists for the rings and asteroids.
            m_Rings = new List<Ring>();
            m_Asteroids = new List<Asteroid>();
            m_Walls = new List<Wall>();
            m_Coins = new List<Coin>();
            m_Clouds = new List<Cloud>();
            m_Zhuzis = new List<Zhuzi>();
            //// Spawn all the starting asteroids.
            //for (int i = 0; i < m_InitialAsteroidCount; i++) //
            //{
            //    SpawnAsteroid();
            //}

            // Restart the score and set the score's type to be FLYER
            SessionData.Restart();
            SessionData.SetGameType(SessionData.GameType.FLYER);

            // The environment has started so spawning can start.
            m_Spawning = true;

            // Start spawning asteroids and rings.
            // StartCoroutine(SpawnAsteroidRoutine());
            //StartCoroutine(SpawnRingRoutine());
            StartCoroutine(SpawnWallRoutine());
            StartCoroutine(SpawnCoinRoutine());
            StartCoroutine(SpawnCloudRoutine());
            StartCoroutine(SpawnZhuziRoutine());
        }



        public void StopEnvironment()
        {
            // The environment has stopped so spawning should no longer happen.
            m_Spawning = false;

            // While there are asteroids in the collection, remove the first asteroid.
            while (m_Asteroids.Count > 0)
            {
                HandleAsteroidRemoval(m_Asteroids[0]);
            }

            // While there are rings in the collection, remove the first ring.
            while (m_Rings.Count > 0)
            {
                HandleRingRemove(m_Rings[0]);
            }

            while (m_Walls.Count > 0)
            {
                HandleWallRemove(m_Walls[0]);
            }

            while (m_Coins.Count > 0)
            {
                HandleCoinRemove(m_Coins[0]);
            }

            while (m_Clouds.Count > 0)
            {
                HandleCloudRemove(m_Clouds[0]);
            }
            while (m_Zhuzis.Count > 0)
            {
                HandleZhuziRemove(m_Zhuzis[0]);
            }
        }
        private IEnumerator SpawnZhuziRoutine()
        {
            // With an initial delay, spawn a ring and delay whilst the environment is spawning.
            yield return new WaitForSeconds(m_ZhuziSpawnFrequency);
            do
            {
                SpawnZhuzi();
                yield return new WaitForSeconds(m_ZhuziSpawnFrequency);
            }
            while (m_Spawning);
        }
        private IEnumerator SpawnCoinRoutine()
        {
            // With an initial delay, spawn a ring and delay whilst the environment is spawning.
            yield return new WaitForSeconds(m_CoinSpawnFrequency);
            do
            {
                SpawnCoin();
                yield return new WaitForSeconds(m_CoinSpawnFrequency);
            }
            while (m_Spawning);
        }
        private IEnumerator SpawnCloudRoutine()
        {
            // With an initial delay, spawn a ring and delay whilst the environment is spawning.
            yield return new WaitForSeconds(m_CloudSpawnFrequency);
            do
            {
                SpawnCloud();
                yield return new WaitForSeconds(m_CloudSpawnFrequency);
            }
            while (m_Spawning);
        }


        /// <summary>
        /// ÿ��һ��ʱ�����ǽ
        /// </summary>
        /// <returns></returns>
        private IEnumerator SpawnWallRoutine()
        {
            // With an initial delay, spawn a ring and delay whilst the environment is spawning.
            yield return new WaitForSeconds(m_WallSpawnFrequency);
            do
            {
                SpawnWall();
                yield return new WaitForSeconds(m_WallSpawnFrequency);
            }
            while (m_Spawning);
        }



        /// <summary>
        /// ÿ��һ��ʱ�䣬����С����
        /// </summary>
        /// <returns></returns>
        private IEnumerator SpawnAsteroidRoutine()
        {
            // While the environment is spawning, spawn an asteroid and wait for another one.
            do
            {
                SpawnAsteroid();
                yield return new WaitForSeconds(m_AsteroidSpawnFrequency);
            }
            while (m_Spawning);
        }

        /// <summary>
        /// 
        /// </summary>
        private void SpawnCoin()
        {
            // for (int i = 0; i < 3; i++)
            {
                // Get a wall from the object pool.
                GameObject coinGameObject = m_CoinObjectPool.GetGameObjectFromPool();

                // Generate a position at a distance forward from the camera within a random sphere and put the ring at that position.
                Vector3 coinPosition = m_Cam.position + Vector3.forward * m_SpawnZoneDistance + UnityEngine.Random.insideUnitSphere * m_CoinSpawnZoneRadius;
                coinGameObject.transform.position = coinPosition;
                float rotate_x = UnityEngine.Random.Range(0, 360);
                float rotate_y = UnityEngine.Random.Range(0, 360);
                float rotate_z = UnityEngine.Random.Range(0, 360);
                Vector3 rotate = new Vector3(rotate_x, rotate_y, rotate_z);
                coinGameObject.transform.rotation = Quaternion.identity;// Quaternion.Euler(rotate);

                Coin coin = coinGameObject.GetComponent<Coin>();
                m_Coins.Add(coin);

                // Subscribe to the remove event.
                coin.OnCoinRemove += HandleCoinRemove;
                // wall.OnWallHit += HandleWallHit;

            }
        }
        private void SpawnCloud()
        {
            for (int i = 0; i < 3; i++)
            {
                // Get a wall from the object pool.
                GameObject cloudGameObject = m_CloudObjectPool.GetGameObjectFromPool();

                // Generate a position at a distance forward from the camera within a random sphere and put the ring at that position.
                Vector3 cloudPosition = m_Cam.position + Vector3.forward * m_SpawnZoneDistance + UnityEngine.Random.insideUnitSphere * m_CloudSpawnZoneRadius;
                cloudGameObject.transform.position = cloudPosition;
                float rotate_x = UnityEngine.Random.Range(0, 360);
                float rotate_y = UnityEngine.Random.Range(0, 360);
                float rotate_z = UnityEngine.Random.Range(0, 360);
                Vector3 rotate = new Vector3(rotate_x, rotate_y, rotate_z);
                cloudGameObject.transform.rotation = Quaternion.identity;// Quaternion.Euler(rotate);

                Cloud cloud = cloudGameObject.GetComponent<Cloud>();
                m_Clouds.Add(cloud);

                // Subscribe to the remove event.
                cloud.OnCloudRemove += HandleCloudRemove;
                // wall.OnWallHit += HandleWallHit;

            }
        }

        /// <summary>
        /// ����ǽ
        /// </summary>
        private void SpawnWall()
        {
            for (int i = 0; i < 2; i++)
            {
                // Get a wall from the object pool.
                GameObject wallGameObject = m_WallObjectPool.GetGameObjectFromPool();


                // Generate a position at a distance forward from the camera within a random sphere and put the ring at that position.
                Vector3 wallPosition = m_Cam.position + Vector3.forward * m_SpawnZoneDistance + UnityEngine.Random.insideUnitSphere * m_WallSpawnZoneRadius;
                wallGameObject.transform.position = wallPosition;
                float rotate_x = UnityEngine.Random.Range(0, 360);
                float rotate_y = UnityEngine.Random.Range(0, 360);
                float rotate_z = UnityEngine.Random.Range(0, 360);
                Vector3 rotate = new Vector3(rotate_x, rotate_y, rotate_z);
                wallGameObject.transform.rotation = Quaternion.identity;// Quaternion.Euler(rotate);

                Wall wall = wallGameObject.GetComponent<Wall>();
                m_Walls.Add(wall);

                // Subscribe to the remove event.
                wall.OnWallRemove += HandleWallRemove;
                // wall.OnWallHit += HandleWallHit;

            }
        }

        private void SpawnZhuzi()
        {
            Vector3 offset = Vector3.zero;
            for (int i = 0; i < 2; i++)
            {
                offset = i == 0 ? new Vector3(-120, 0, 0) : new Vector3(120, 0, 0);


                // Get a wall from the object pool.
                GameObject circleGameObject = m_ZhuziObjectPool.GetGameObjectFromPool();

                Vector3 circlePosition = m_Cam.position + Vector3.forward * m_SpawnZoneDistance + offset;// new Vector3(-30f,-30f,0); //UnityEngine.Random.insideUnitSphere * m_ZhuziSpawnZoneRadius;
                circleGameObject.transform.position = circlePosition;
                circleGameObject.transform.rotation = Quaternion.identity;

                Zhuzi zhuzi = circleGameObject.GetComponent<Zhuzi>();
                m_Zhuzis.Add(zhuzi);

                // Subscribe to the remove event.
                zhuzi.OnZhuziRemove += HandleZhuziRemove;
                // wall.OnWallHit += HandleWallHit;
            }
        }

        /// <summary>
        /// ����С����
        /// </summary>
        private void SpawnAsteroid()
        {
            // Get an asteroid from the object pool.
            GameObject asteroidGameObject = m_AsteroidObjectPool.GetGameObjectFromPool();

            // Generate a position at a distance forward from the camera within a random sphere and put the asteroid at that position.
            Vector3 asteroidPosition = m_Cam.position + Vector3.forward * m_SpawnZoneDistance + UnityEngine.Random.insideUnitSphere * m_AsteroidSpawnZoneRadius;
            asteroidGameObject.transform.position = asteroidPosition;

            // Get the asteroid component and add it to the collection.
            Asteroid asteroid = asteroidGameObject.GetComponent<Asteroid>();
            m_Asteroids.Add(asteroid); //�ӵ��б���

            // Subscribe to the asteroids events.
            asteroid.OnAsteroidRemovalDistance += HandleAsteroidRemoval; // ����С�����Ƴ�����
            asteroid.OnAsteroidHit += HandleAsteroidHit; //����С����ײ������
        }


        /// <summary>
        /// ÿ��һ��ʱ�䣬����ԲȦ
        /// </summary>
        /// <returns></returns>
        private IEnumerator SpawnRingRoutine()
        {
            // With an initial delay, spawn a ring and delay whilst the environment is spawning.
            yield return new WaitForSeconds(m_RingSpawnFrequency);
            do
            {
                SpawnRing();
                yield return new WaitForSeconds(m_RingSpawnFrequency);
            }
            while (m_Spawning);
        }


        /// <summary>
        /// ����ԲȦ
        /// </summary>
        private void SpawnRing()
        {
            // Get a ring from the object pool.
            GameObject ringGameObject = m_RingObjectPool.GetGameObjectFromPool();

            // Generate a position at a distance forward from the camera within a random sphere and put the ring at that position.
            Vector3 ringPosition = m_Cam.position + Vector3.forward * m_SpawnZoneDistance + UnityEngine.Random.insideUnitSphere * m_RingSpawnZoneRadius;
            ringGameObject.transform.position = ringPosition;

            // Get the ring component, restart it and add it to the collection.
            Ring ring = ringGameObject.GetComponent<Ring>();
            ring.Restart();
            m_Rings.Add(ring);

            // Subscribe to the remove event.
            ring.OnRingRemove += HandleRingRemove;
        }


        /// <summary>
        /// �Ƴ���ǰС���ǵ� ����¼������б����Ƴ����黹�������
        /// </summary>
        /// <param name="asteroid"></param>
        private void HandleAsteroidRemoval(Asteroid asteroid)
        {
            // Only one of HandleAsteroidRemoval and HandleAsteroidHit should be called so unsubscribe both.
            asteroid.OnAsteroidRemovalDistance -= HandleAsteroidRemoval;
            asteroid.OnAsteroidHit -= HandleAsteroidHit;

            // Remove the asteroid from the collection.
            m_Asteroids.Remove(asteroid);

            // Return the asteroid to its object pool.
            m_AsteroidObjectPool.ReturnGameObjectToPool(asteroid.gameObject);
        }


        /// <summary>
        /// ײ�����������ű�ը��Ч�� ��ը��ЧҲ�ǴӶ�����л�ȡ
        /// </summary>
        /// <param name="asteroid"></param>
        private void HandleAsteroidHit(Asteroid asteroid)
        {
            // Remove the asteroid when it's hit.
            HandleAsteroidRemoval(asteroid);

            // Get an explosion from the object pool and put it at the asteroids position.
            GameObject explosion = m_AsteroidExplosionObjectPool.GetGameObjectFromPool();
            explosion.transform.position = asteroid.transform.position;

            // Get the asteroid explosion component and restart it.
            AsteroidExplosion asteroidExplosion = explosion.GetComponent<AsteroidExplosion>();
            asteroidExplosion.Restart();

            // Subscribe to the asteroid explosion's event.
            asteroidExplosion.OnExplosionEnded += HandleExplosionEnded;
        }

        /// <summary>
        /// ǽ����ײ����
        /// </summary>
        /// <param name="obj"></param>
        private void HandleWallHit(Wall obj)
        {
            HandleWallRemove(obj);

            GameObject explosion = m_AsteroidExplosionObjectPool.GetGameObjectFromPool();
            explosion.transform.position = obj.transform.position;

            AsteroidExplosion asteroidExplosion = explosion.GetComponent<AsteroidExplosion>();
            asteroidExplosion.Restart();

            asteroidExplosion.OnExplosionEnded += HandleExplosionEnded;
        }


        /// <summary>
        /// ��ը��Ч������ �黹�������
        /// </summary>
        /// <param name="explosion"></param>
        private void HandleExplosionEnded(AsteroidExplosion explosion)
        {
            // Now the explosion has finished unsubscribe from the event.
            explosion.OnExplosionEnded -= HandleExplosionEnded;

            // Return the explosion to its object pool.
            m_AsteroidExplosionObjectPool.ReturnGameObjectToPool(explosion.gameObject);
        }


        /// <summary>
        /// ԲȦ���Ƴ����,���б����Ƴ����黹�������
        /// </summary>
        /// <param name="ring"></param>
        private void HandleRingRemove(Ring ring)
        {
            // Now the ring has been removed, unsubscribe from the event.
            ring.OnRingRemove -= HandleRingRemove;

            // Remove the ring from it's collection.
            m_Rings.Remove(ring);

            // Return the ring to its object pool.
            m_RingObjectPool.ReturnGameObjectToPool(ring.gameObject);
        }

        /// <summary>
        /// ǽ���Ƴ����,���б����Ƴ����黹�������
        /// </summary>
        /// <param name="wall"></param>
        private void HandleWallRemove(Wall wall)
        {
            // Now the ring has been removed, unsubscribe from the event.
            wall.OnWallRemove -= HandleWallRemove;

            // wall.OnWallHit -= HandleWallHit;

            m_Walls.Remove(wall);

            m_WallObjectPool.ReturnGameObjectToPool(wall.gameObject);
        }


        private void HandleCoinRemove(Coin coin)
        {
            // Now the ring has been removed, unsubscribe from the event.
            coin.OnCoinRemove -= HandleCoinRemove;

            // wall.OnWallHit -= HandleWallHit;

            m_Coins.Remove(coin);

            m_CoinObjectPool.ReturnGameObjectToPool(coin.gameObject);
        }

        private void HandleCloudRemove(Cloud cloud)
        {
            // Now the ring has been removed, unsubscribe from the event.
            cloud.OnCloudRemove -= HandleCloudRemove;

            // wall.OnWallHit -= HandleWallHit;

            m_Clouds.Remove(cloud);

            m_CloudObjectPool.ReturnGameObjectToPool(cloud.gameObject);
        }

        private void HandleZhuziRemove(Zhuzi zhuzi)
        {
            zhuzi.OnZhuziRemove -= HandleZhuziRemove;

            m_Zhuzis.Remove(zhuzi);

            m_ZhuziObjectPool.ReturnGameObjectToPool(zhuzi.gameObject);
        }
    }
}