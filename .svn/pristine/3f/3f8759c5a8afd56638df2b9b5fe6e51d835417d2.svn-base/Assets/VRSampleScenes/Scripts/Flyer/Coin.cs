﻿using UnityEngine;
using System.Collections;
using System;
using VRStandardAssets.Flyer;


public class Coin : MonoBehaviour
{

    public event Action<Coin> OnCoinRemove;
    //public event Action<Wall> OnWallHit;

    private Transform m_Cam;
    private GameObject m_Flyer;
    private const float k_RemovalDistance = 50f;
    private FlyerHealthController m_FlyerHealthController;
    void Awake()
    {
        // Set references to the camera and flyer.
        m_Cam = Camera.main.transform;
        m_Flyer = GameObject.FindGameObjectWithTag("Player");

        m_FlyerHealthController = FindObjectOfType<FlyerHealthController>();
        m_Flyer = m_FlyerHealthController.gameObject;
    }

    void Start()
    {

    }

    void Update()
    {
        if (transform.position.z < m_Cam.position.z - k_RemovalDistance)
        {
            if (OnCoinRemove != null)
                OnCoinRemove(this);
        }

       transform.Rotate(new Vector3(0,120,0) * Time.deltaTime);
    }


    private void OnDestroy()
    {
        // Ensure the event is completely unsubscribed when the ring is destroyed.
        OnCoinRemove = null;
    }
   
}
