﻿using UnityEngine;
using System.Collections;
using System;
using VRStandardAssets.Flyer;


public class Wall : MonoBehaviour
{

    public event Action<Wall> OnWallRemove;
    //public event Action<Wall> OnWallHit;

    private Transform m_Cam;
    private GameObject m_Flyer;
    private const float k_RemovalDistance = 50f;
    private FlyerHealthController m_FlyerHealthController;
    private FlyerMovementController m_flyerMovementController;
    void Awake()
    {
        // Set references to the camera and flyer.
        m_Cam = Camera.main.transform;
        m_Flyer = GameObject.FindGameObjectWithTag("Player");

        m_FlyerHealthController = FindObjectOfType<FlyerHealthController>();
        m_Flyer = m_FlyerHealthController.gameObject;

        m_flyerMovementController =  m_Flyer.GetComponent<FlyerMovementController>();
    }

    void Start()
    {

    }

    void Update()
    {
        if (transform.position.z < m_Cam.position.z - k_RemovalDistance)
        {
            GlobalData.m_pastedObstacleCount++;
            //判断速度是否要提档
            //if (GlobalData.m_pastedObstacleCount % 4 == 0)
            if(GlobalData.m_finalFlyDistance % 1200 == 0)
            {
                m_flyerMovementController.AddSpeed();
            }

            if (OnWallRemove != null)
                OnWallRemove(this);
        }
    }


    private void OnDestroy()
    {
        // Ensure the event is completely unsubscribed when the ring is destroyed.
        OnWallRemove = null;
    }
    //private void OnTriggerEnter(Collider other)
    //{
    //    // Only continue if the asteroid has hit the flyer.
    //    if (other.gameObject != m_Flyer)
    //        return;

    //    // Damage the flyer.
    //    m_FlyerHealthController.TakeDamage(100);

    //    // If the damage didn't kill the flyer add to the score and call the appropriate events.
    //    if (!m_FlyerHealthController.IsDead)
    //        Hit();
    //}


    public void Hit()
    {
        // Add to the score.
       // SessionData.AddScore(m_Score);

        //if (OnWallHit != null)
        //    OnWallHit(this);
    }

}
