﻿using System;
using UnityEngine;
using System.Collections;

public class SelfInputMgr : MonoBehaviour
{
    public Action keyDownCallback;
    private bool isAnyKeyDown = false;
    void Start()
    {

    }

    void Update()
    {
        if (Input.anyKeyDown) //any keyboard or mouse click
        {
            isAnyKeyDown = true;
            if (keyDownCallback != null)
            {
                keyDownCallback();
            }
        }
        else
        {

            isAnyKeyDown = false;
        }
    }

    public IEnumerator WaitForAnyKeyDown()
    {
        while (!isAnyKeyDown)
        {
            yield return null;
        }
    }
}
