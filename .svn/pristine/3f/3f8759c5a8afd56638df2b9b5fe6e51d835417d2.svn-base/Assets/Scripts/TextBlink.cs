﻿using UnityEngine;
using System.Collections;
using DG.Tweening;
using UnityEngine.UI;

public class TextBlink : MonoBehaviour
{
    public Text text;

	// Use this for initialization
	void Start ()
	{
	    text.DOFade(0, 1f).SetLoops(-1, LoopType.Yoyo);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
