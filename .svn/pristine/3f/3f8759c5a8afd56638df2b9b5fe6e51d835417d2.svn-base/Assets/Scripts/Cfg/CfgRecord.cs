﻿using UnityEngine;
using System.Collections.Generic;
using System.Xml.Serialization;

[System.Serializable]
public class RecordItem
{
    [XmlAttribute("m_id")]
    public int m_id;

    [XmlAttribute("m_name")]
    public string m_name;

    [XmlAttribute("m_score")]
    public int m_score;
}

[XmlRoot("Root")]
public class CfgRecordMgr
{
    [XmlArray("List"), XmlArrayItem("Item")]
    public List<RecordItem> m_dataList;

    public RecordItem FindById(int id)
    {
        return m_dataList.Find(x => x.m_id == id);
    }
}