﻿using UnityEngine;
using System.Collections.Generic;
using System.IO;
using System;

public class RecordMgr
{
    public int currId;
    private string currName;
    private int currScore;

    string path = Application.persistentDataPath + "/record.xml";

    private static RecordMgr m_inst;
    public static RecordMgr Inst
    {
        get
        {
            if (m_inst == null)
            {
                m_inst = new RecordMgr();
            }
            return m_inst;
        }
    }

    public RecordMgr()
    {
        LoadCacheRecord();
    }

    public void LoadCacheRecord()
    {
        if (File.Exists(path))
        {
            //Debug.Log("exist");
            CfgRecordMgr rmgr = null;
            try
            {
                rmgr = XmlHelper.ParseXml<CfgRecordMgr>(path, typeof(CfgRecordMgr),false);
            }
            catch (Exception e)
            {
                rmgr = null;
            }

            if (rmgr != null)
                GlobalData.m_recordMgr = rmgr;
            else
            {
                GlobalData.m_recordMgr = null;
                Debug.Log("load record.xml failed");
            }
        }
        else
        {
            GlobalData.m_recordMgr = null;
            //Debug.Log("not exist");
        }
    }

    public void StartRecord(RecordItem _recordItem)
    {
        this.currId = _recordItem.m_id;
        this.currName = _recordItem.m_name;
        this.currScore = _recordItem.m_score;
    }

    public void StopRecord( )
    {
        ExcuteRecord();
    }

    private void ExcuteRecord()
    {
        if (GlobalData.m_recordMgr == null)
        {
            GlobalData.m_recordMgr = new CfgRecordMgr();
            RecordItem ri = new RecordItem();
            ri.m_id = currId;
            ri.m_name = currName;
            ri.m_score = currScore;
            GlobalData.m_recordMgr.m_dataList = new List<RecordItem>();
            GlobalData.m_recordMgr.m_dataList.Add(ri);
        }
        else
        {
            RecordItem ri = new RecordItem();
            ri.m_id = currId;
            ri.m_name = currName;
            ri.m_score = currScore;
            GlobalData.m_recordMgr.m_dataList.Add(ri);
        }

        SortRecord();
        XmlHelper.SaveXml(path, GlobalData.m_recordMgr, typeof(CfgRecordMgr),true);
        Debug.Log("record ok");
    }

    /// <summary>
    /// 降序排序，排行榜从高到底排序
    /// </summary>
    private void SortRecord()
    {
        List<RecordItem> itemList =  GlobalData.m_recordMgr.m_dataList;
        itemList.Sort(new Comparison<RecordItem>(delegate(RecordItem item, RecordItem recordItem)
        {
           return -item.m_score.CompareTo(recordItem.m_score); //-号，降序，不加就是升序
        }));

        List<RecordItem> sortItemList = itemList;
        GlobalData.m_recordMgr.m_dataList = sortItemList;
    }
}
