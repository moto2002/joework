﻿using UnityEngine;
using System.Collections;
using DG.Tweening;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SplashScript : MonoBehaviour
{
    public Image logo;

    void Start()
    {
        Camera mainCamera = Camera.main;
        //camera show
        mainCamera.DOColor(Color.white, 2f).SetDelay(0.5f).SetEase(Ease.InOutQuart).OnComplete(() =>
        {
            mainCamera.DOColor(Color.black, 2f).SetDelay(2f).SetEase(Ease.InOutQuart).OnComplete(() =>
            {
                SceneManager.LoadSceneAsync("Main");
            });
        });

        //logo show
        logo.DOFade(1f, 2f).SetDelay(0.5f).SetEase(Ease.InOutQuart).OnComplete(() =>
        {
            logo.DOFade(0, 2f).SetDelay(2f).SetEase(Ease.InOutQuart).OnComplete(() =>
            {
                
            });
        });
    }

    void Update()
    {

    }
}
