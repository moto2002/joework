﻿using UnityEngine;
using System.Collections;

public class GlobalData
{
    public static CfgRecordMgr m_recordMgr;//游戏记录

    public static int m_finalFlyDistance; //飞行距离

    public static int m_coinCount;//金币数

    public static int m_score;//积分

    public static int m_pastedObstacleCount;//飞过的障碍物的个数，见策划文档： 飞行器的飞行速度会越来越快（与通过的段落数有关）暂定为每通过6个段落速度增加1个档次，暂定一个档次的速度递增为20



}
